python $PWD/WOT.py
