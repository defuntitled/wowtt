from tkinter import *
from random import choice
from readimage import *
from wot_game_of import *
from wot_game_gachi_of import *
from wot_payments import *
import time
G=0
def inass1():
	a=entt1.get()
	win1.destroy() 
	if G==1:
		ingachi(a)
	else:
		inass(a)
def keypressed(event):
	k=event.keycode
	if k==36:
		inass1()
#boginya
def pay():
	win1.destroy()
	inasspay()
	#pay here
	#with open('config.gachi','w') as f:
	#	f.write("payed")
	#	butt2.config(text=(chr(9794) + ' В GACHI ' + chr(9794)),command=gachi)
def gachi():
	global G
	if G==0:
		G=1
		lab1.config(text=(chr(9794) + ' МИР GACHIMUCHI ' + chr(9794)))
		win1.title('GYM')
		butt1.config(text=(chr(9794) + ' GO DEEP ' + chr(9794)))
		butt2.config(text='В танки')
	else:
		G=0
		lab1.config(text=(chr(9794) + ' МИР ВОЕННЫХ ТАНКОВ ' + chr(9794)))
		win1.title('ДОЛБЕЖКА')
		butt1.config(text=(chr(9794) + ' В БОЙ ' + chr(9794)))
		butt2.config(text=(chr(9794) + ' В GACHI ' + chr(9794)))
fon=['images.jpg']
win1=Tk()
win1.title('скачано с torrent.su')
win1.geometry('450x200') 
superfon=readimg(fon)
try:
	with open('config.gachi','r') as f:
		if f.read()=='payed':
			butt2=Button(win1,text=(chr(9794) + ' В GACHI ' + chr(9794)),width=15,font='arial 16',bg='gray',fg='black',command=gachi)
		else:
			butt2=Button(win1,text=(chr(9794) + ' PAY 300$ ' + chr(9794)),width=15,font='arial 16',bg='gray',fg='black',command=pay)
except:
	with open('config.gachi','w') as f:
		f.write("fuck you")
		butt2=Button(win1,text=(chr(9794) + ' PAY 300$ ' + chr(9794)),width=15,font='arial 16',bg='gray',fg='black',command=pay)
pole=Canvas(win1, height=450, width=200, bg="white")
pole.create_image(10,10,image=superfon[0],anchor='nw')
lab1=Label(win1,text=(chr(9794) + ' МИР ВОЕННЫХ ТАНКОВ ' + chr(9794)),width=30,font='arial 22',bg='magenta',fg='black')
lab2=Label(win1,text='Логин:',width=10,font='arial 10',bg='gray',fg='magenta')
entt1=Entry(win1,width=15,font='arial 10',bg='white',fg='magenta')
butt1=Button(win1,text=(chr(9794) + ' В БОЙ ' + chr(9794)),width=15,font='arial 32',bg='gray',fg='black',command=inass1)
lab1.place(x=50,y=10)
entt1.place(x=20,y=60)
butt1.place(x=70,y=100)
butt2.place(x=260,y=160)
lab2.place(x=20,y=45)
win1.bind('<Key>',keypressed)
win1.mainloop()
