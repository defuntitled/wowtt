from tkinter import *
from random import choice
import time
ms=['Fisting is 300$','deep dark fantasies','fuck you!','so fucking deep','ass we can','AAAAAAAAAAA','my fucking pants','oh yes sir','sorry for that','swallow my cum','another victim','Hey buddy','another one','oh my fucking pants','another one','oh my fucking pants','another one','oh my fucking pants','another one','oh my fucking pants','do you like what you see?','do you like what you see?','do you like watching me? Its okey','do you like watching me? Its okey','do you like watching me? Its okey','Without further interruption']
#ms=['Without further interruption']
import sys
p=0
#'Without further interruption'
asshits=0
td=0
sd=0
ANAL=0
ip=0
hb=0
fb=0
s='			ТАААААААААААНКДУЛООООООООО 8===>'
r='		    ТАААААААААААНКДУЛООООООООО   '
def keypressed(event):
	k=event.keycode
	if k==113:
		FIRE()
	if k==114:
		RELOAD()
def FIRE():
	global p, lab4,lab14, lab17,lab18,asshits,td,sd,lab20,ANAL,ip,truenick,hb,fb
	if p==0:
		if asshits==4:
			lab4.config(text=s)
			if (truenick == 'Billy'):
				lab14.config(text=(chr(9794) + 'Leatherman' + chr(9794) + ' destroyed'))
			elif (truenick == 'Leatherman'):
				lab14.config(text=(chr(9794) + 'Billy' + chr(9794) + ' destroyed'))
			elif (truenick == 'Fucking_slave'):
				lab14.config(text=(chr(9794) + 'Boss of gym' + chr(9794) + ' destroyed'))
			else:
				lab14.config(text=(chr(9794) + 'Fucking slave' + chr(9794) + ' destroyed'))
			asshits=0
			td+=1
			p=1
		else:
			lab4.config(text=s)
			f=choice(ms)
			if (f == 'Hey buddy') and (hb==0):
				hb=1
			elif hb==1:
				f='You selected the wrong door'
				hb=2
			elif hb==2:
				f='letherclub is 2 blocks down'
				if truenick=='Billy':
					hb=0
					asshits=4
				else:
					hb+=1
			elif hb==3:
				f='FUCK YOUUUUU'
				hb=0
				td+=3
				asshits=0
			if f == 'swallow my cum':
				asshits+=2
			if f == 'ass we can': 
				asshits=0
				td+=1
			if (f!='AAAAAAAAAAA') or (f!='sorry for that'):
				asshits+=1
			if (f == 'Without further interruption') and (fb==0):
				fb=1
			elif fb==1:
				f='Lets celebrate and suck some dick'
				fb=0
				asshits=4
		lab14.config(text=f)
		lab18.config(text=(chr(9794) + 'FUCKING CUMMING' + chr(9794)))
		p=1
		root.after(3000,cum)
	else:
		lab14.config(text=(chr(9794) + 'AAAAAAAAAAAAAA' + chr(9794)))
		sd+=1
	lab17.config(text=td)
	lab20.config(text=sd)
	if ip==1:
		RELOAD()
	if sd==5:
		ANAL=1
		FAIL()
def RELOAD():
	global p, lab4,lab14,lab18,butt2,ip,hb
	if ip!=1:
		lab4.config(text=r)
		lab14.config(text='')
		lab18.config(text=(chr(9794) + 'WOO' + chr(9794)))
		butt2.config(command='')
		root.after(5000,yrght)
	else:
		p=0
		lab18.config(text=(chr(9794) + 'CUM READY' + chr(9794)))
def yrght():
	global p,butt2
	butt2.config(command=RELOAD)
	lab18.config(text=(chr(9794) + 'CUM READY' + chr(9794)))
	p=0
def FAIL():
	global root,ANAL
	root.destroy()
	root=Tk()
	root.title('no, i dont do anal')
	root.geometry('800x600')
	butt1=Button(root,text='FUCK YOU',width=50,height=20,font='arial 30',bg='magenta',fg='yellow',command=ass)
	butt1.place(x=0,y=0)
	root.after(10000,ass)
	root.mainloop()
def ass():
	sys.exit()
def cum():
	global lab18
	lab18.config(text=('NEED MORE' + chr(9794) +' CUM' + chr(9794)))
def ingachi(nick):
	global lab4,lab14, entt1, lab17,lab18,butt2,lab20,truenick    
	global root
	if nick == 'Dungeon_master' or nick == 'Fucking_slave' or nick == 'Boss_of_gym' or nick == 'Leatherman' or nick == 'Boy_next_door' or nick == 'Billy': 
		truenick=nick
		if nick == 'Dungeon_master':
			global ip
			ip=1
		root=Tk()	
		root.title(chr(9794) + ' ' + 'fisting ass'+ ' ' + chr(9794))
		root.geometry('1200x600')
		pole=Canvas(root,width=1200,height=600,bg='yellow')
		pole.place(x=0,y=00)
		lab1=Label(root,text='ТААААААААААНК',width=80,font='arial 22',bg='yellow',fg='black')
		lab2=Label(root,text='ТААААААААААААНК',width=80,font='arial 22',bg='yellow',fg='black')
		lab3=Label(root,text='ТААААААААААААНК',width=80,font='arial 22',bg='yellow',fg='black')
		lab4=Label(root,text=r,width=80,font='arial 22',bg='yellow',fg='black')
		lab6=Label(root,text='ТААААААААААААНК',width=80,font='arial 22',bg='yellow',fg='black')
		lab7=Label(root,text='__ТАААААААААААААААААААААААААААААААААНК__',width=80,font='arial 22',bg='yellow',fg='black')
		lab8=Label(root,text='ТААААААААААААААААААААААААНК',width=80,font='arial 22',bg='yellow',fg='black')
		lab9=Label(root,text='ТАААААААААААААААААААААААААААААААНК',width=80,font='arial 22',bg='yellow',fg='black')
		lab10=Label(root,text='I                                                                                                                                               I',width=80,font='arial 22',bg='yellow',fg='black')
		lab11=Label(root,text='I                                                                                                                                               I',width=80,font='arial 22',bg='yellow',fg='black')
		lab12=Label(root,text='I                                                                                                                                               I',width=80,font='arial 22',bg='yellow',fg='black')
		lab13=Label(root,text='\_________________________________________________________________/',width=80,font='arial 22',bg='yellow',fg='black')
		lab14=Label(root,text=' ',width=30,font='arial 16',bg='yellow',fg='magenta')
		lab15=Label(root,text=nick,width=20,font='arial 16',bg='gray',fg='magenta')	
		lab16=Label(root,text=(chr(9794) + 'Fucking slaves' + chr(9794) + ' destroyed:'),width=25,font='arial 16',bg='gray',fg='magenta')
		if (nick == 'Billy'):
			lab16.config(text=(chr(9794) + 'Leathermans' + chr(9794) + ' destroyed:'))
		if (nick == 'Leatherman'):
			lab16.config(text=(chr(9794) + 'Billys' + chr(9794) + ' destroyed:'))
		if (nick == 'Fucking_slave'):
			lab16.config(text=(chr(9794) + 'Boss of gyms' + chr(9794) + ' destroyed:'))
		lab17=Label(root,text=td,width=3,font='arial 12',bg='gray',fg='magenta')
		lab18=Label(root,text=(chr(9794) + 'CUM READY' + chr(9794)),width=30,font='arial 12',bg='gray',fg='magenta')
		lab19=Label(root,text=(chr(9794) + 'ASS DESTROYED' + chr(9794)),width=30,font='arial 12',bg='gray',fg='magenta')
		lab20=Label(root,text=sd,width=3,font='arial 12',bg='gray',fg='magenta')
		lab1.place(x=5,y=100)
		lab2.place(x=5,y=130)
		lab3.place(x=5,y=160)
		lab4.place(x=5,y=190)
		lab6.place(x=5,y=220)
		lab7.place(x=5,y=310)
		lab8.place(x=5,y=250)        
		lab9.place(x=5,y=280)
		lab10.place(x=5,y=340)
		lab11.place(x=5,y=370)
		lab12.place(x=5,y=400)
		lab13.place(x=5,y=430)
		lab14.place(x=100,y=50)
		lab15.place(x=850,y=30)
		lab16.place(x=100,y=30)
		lab17.place(x=335,y=30)
		lab18.place(x=750,y=500)
		lab19.place(x=100,y=10)
		lab20.place(x=335,y=10)
		butt1=Button(root,text='CUMMING!!!!',width=17,font='arial 16',bg='red',fg='black',command=FIRE)
		butt2=Button(root,text='PREPARE YOUR CUM!!!!',width=17,font='aria16',bg='gray',fg='black',command=RELOAD)
		butt3=Button(root,text='Сдаться',width=15,font='arial 16',bg='gray',fg='black',command=FAIL)
		butt3.place(x=500,y=500)
		butt1.place(x=20,y=500)
		butt2.place(x=200,y=500)
		root.bind('<Key>',keypressed)
		root.mainloop()
	else: sys.exit()
