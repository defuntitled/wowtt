Используйте для запуска RUN.sh
Если не работает, то правой кнопокй мыши в проводнике->открыть терминал
в терминале прописать chmod +x RUN.sh
------------------------------
реквизиты оплаты 1337-1337-1337-1377; 69/69; 228
гачи ники:  nick == 'Dungeon_master' or nick == 'Fucking_slave' or nick == 'Boss_of_gym' or nick == 'Leatherman' or nick == 'Boy_next_door' or nick == 'Billy'
простые ники: nick == 'ivannavi' or nick == 'timofeieschyintima' or nick == 'egorka' 



------------------------------
Авторы:
vvputinv 
dungeon_master2003